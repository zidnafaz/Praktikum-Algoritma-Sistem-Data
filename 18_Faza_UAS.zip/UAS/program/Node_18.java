package program;

public class Node_18 {

    TransaksiPajak data;
    Node_18 next;

    public Node_18(TransaksiPajak data, Node_18 next) {
        this.data = data;
        this.next = next;
    }
    
}