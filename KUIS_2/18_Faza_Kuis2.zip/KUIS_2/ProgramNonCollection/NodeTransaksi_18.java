package ProgramNonCollection;

public class NodeTransaksi_18 {
    Transaksi_18 transaksi;
    NodeTransaksi_18 next;

    public NodeTransaksi_18(Transaksi_18 transaksi, NodeTransaksi_18 next) {
        this.transaksi = transaksi;
        this.next = next;
    }
}