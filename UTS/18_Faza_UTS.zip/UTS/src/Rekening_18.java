public class Rekening_18 {
    
    String noRekening, nama, namaIbu, telp, email;

    Rekening_18(String noRekening, String nama, String namaIbu, String telp, String email) {
        this.noRekening = noRekening;
        this.nama = nama;
        this. namaIbu = namaIbu;
        this.telp = telp;
        this.email = email;
    }
}