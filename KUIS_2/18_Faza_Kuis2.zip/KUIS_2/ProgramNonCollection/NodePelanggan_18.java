package ProgramNonCollection;

public class NodePelanggan_18 {
    Pelanggan_18 pelanggan;
    NodePelanggan_18 next;

    public NodePelanggan_18(Pelanggan_18 pelanggan, NodePelanggan_18 next) {
        this.pelanggan = pelanggan;
        this.next = next;
    }
}